<html> 
  <head>
    <title>noodle.ml</title>
    <meta http-equiv="refresh" content="1; URL=http://domain.dot.tk/p/?d=NOODLE.ML&i=198.12.97.86&c=1&ro=0&ref=unknown&_=1483551868592"/>
    <script type="text/javascript">
    <!--
      function redir(){ var $fwd = 'http://domain.dot.tk/p/?d=NOODLE.ML&i=198.12.97.86&c=1&ro=0&ref=unknown&_=1483551868592'; if(window.parent){ window.parent.location=$fwd; }else{ window.location=$fwd; }}
    //-->
    </script>
  </head>
  <body onload="redir()">
    <script language="text/javascript">
    <!--
      window.setTimeout('redir();', 50 * 1);
    //-->
    </script>
  </body>
</html>
